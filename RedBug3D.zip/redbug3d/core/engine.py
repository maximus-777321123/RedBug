import glfw
import moderngl
import numpy as np

class Engine3D:
    def __init__(self, title="RedBug 3D", width=1280, height=720,
                 fullscreen=False, vsync=True,
                 clear_color=(0.8, 0.8, 0.8, 1.0)):
        self.title = title
        self.width = width
        self.height = height
        self.fullscreen = fullscreen
        self.vsync = vsync
        self.clear_color = clear_color
        self.window = None
        self.ctx = None
        self.running = False
        self.world = None
        self._last_time = 0.0
        self._delta_time = 0.0
        self.fps = 0
        self._frame_count = 0
        self._fps_timer = 0.0
        self.depth_texture = None

    def init(self):
        if not glfw.init():
            raise RuntimeError("GLFW init failed!")

        glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 3)
        glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 3)
        glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)
        glfw.window_hint(glfw.RESIZABLE, glfw.TRUE)
        glfw.window_hint(glfw.DEPTH_BITS, 24)

        monitor = glfw.get_primary_monitor() if self.fullscreen else None
        self.window = glfw.create_window(self.width, self.height, self.title, monitor, None)
        if not self.window:
            glfw.terminate()
            raise RuntimeError("Window creation failed!")

        glfw.make_context_current(self.window)
        glfw.swap_interval(1 if self.vsync else 0)

        self.ctx = moderngl.create_context()
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.ctx.enable(moderngl.CULL_FACE)
        self.ctx.cull_face = 'back'

        self.depth_texture = self.ctx.depth_texture((self.width, self.height))
        self.depth_texture.repeat_x = False
        self.depth_texture.repeat_y = False

        glfw.set_framebuffer_size_callback(self.window, self._on_resize)
        glfw.set_key_callback(self.window, self._on_key)
        glfw.set_cursor_pos_callback(self.window, self._on_mouse_move)
        glfw.set_input_mode(self.window, glfw.CURSOR, glfw.CURSOR_DISABLED)

        self._last_time = glfw.get_time()
        print(f"[RedBug 3D] OK: {self.width}x{self.height} - {self.title}")

    def run(self, world):
        self.world = world
        self.init()
        self.running = True

        from ..io.input_manager import Input3D
        Input3D.initialize(self.window)

        while self.running and not glfw.window_should_close(self.window):
            current_time = glfw.get_time()
            self._delta_time = current_time - self._last_time
            self._last_time = current_time

            self._frame_count += 1
            self._fps_timer += self._delta_time
            if self._fps_timer >= 1.0:
                self.fps = self._frame_count
                self._frame_count = 0
                self._fps_timer -= 1.0

            Input3D._update()
            glfw.poll_events()

            if Input3D.get_key(256):  # ESC
                self.running = False

            self.ctx.clear(*self.clear_color)
            self.world.update(self._delta_time)
            glfw.swap_buffers(self.window)

        self.shutdown()

    def shutdown(self):
        self.running = False
        if self.world:
            self.world.destroy()
        if self.depth_texture:
            self.depth_texture.release()
        if self.ctx:
            self.ctx.release()
        if self.window:
            glfw.destroy_window(self.window)
        glfw.terminate()
        print("[RedBug 3D] Shutdown.")

    @property
    def delta_time(self):
        return self._delta_time

    def _on_resize(self, window, width, height):
        self.width = width
        self.height = height
        if self.ctx:
            self.ctx.viewport = (0, 0, width, height)
            if self.depth_texture:
                self.depth_texture.release()
            self.depth_texture = self.ctx.depth_texture((width, height))

    def _on_key(self, window, key, scancode, action, mods):
        from ..io.input_manager import Input3D
        Input3D._on_key(key, action)

    def _on_mouse_move(self, window, x, y):
        from ..io.input_manager import Input3D
        Input3D._on_mouse_move(x, y)
