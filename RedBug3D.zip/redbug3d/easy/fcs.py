from redbug3d import Engine3D, World
from redbug3d.ecs.component import Transform3D, MeshRenderer, Camera3D, FlyController, Rotator, Light
from redbug3d.ecs.system import System
from redbug3d.graphics.texture import texture_manager
from redbug3d.graphics.mesh import MeshCache
from redbug3d.graphics.camera import PerspectiveCamera
from redbug3d.graphics.shader import VERTEX_SHADER_3D, FRAGMENT_SHADER_3D
from redbug3d.io.input_manager import Input3D
import glfw
class FlyControllerSystem(System):
    def __init__(self, camera):
        super().__init__()
        self.camera = camera

    def update(self, dt):
        for entity in self.world.get_entities_with(Camera3D, FlyController):
            cam = self.world.get_component(entity, Camera3D)
            ctrl = self.world.get_component(entity, FlyController)

            speed = ctrl.speed * dt
            if Input3D.get_key(glfw.KEY_W):
                self.camera.position += self.camera.front * speed
            if Input3D.get_key(glfw.KEY_S):
                self.camera.position -= self.camera.front * speed
            if Input3D.get_key(glfw.KEY_A):
                self.camera.position -= self.camera.right * speed
            if Input3D.get_key(glfw.KEY_D):
                self.camera.position += self.camera.right * speed
            if Input3D.get_key(glfw.KEY_SPACE):
                self.camera.position += self.camera.up * speed
            if Input3D.get_key(glfw.KEY_LEFT_SHIFT):
                self.camera.position -= self.camera.up * speed

            dx, dy = Input3D.get_mouse_delta()
            self.camera.yaw += dx * cam.mouse_sensitivity
            self.camera.pitch -= dy * cam.mouse_sensitivity
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.camera._dirty = True


