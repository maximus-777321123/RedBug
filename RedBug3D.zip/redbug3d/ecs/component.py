from dataclasses import dataclass
from typing import Tuple
import numpy as np

@dataclass
class Transform3D:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    rot_x: float = 0.0
    rot_y: float = 0.0
    rot_z: float = 0.0
    scale_x: float = 1.0
    scale_y: float = 1.0
    scale_z: float = 1.0

    def get_matrix(self):
        trans = np.eye(4, dtype=np.float32)
        trans[0, 3] = self.x
        trans[1, 3] = self.y
        trans[2, 3] = self.z

        cx, sx = np.cos(self.rot_x), np.sin(self.rot_x)
        cy, sy = np.cos(self.rot_y), np.sin(self.rot_y)
        cz, sz = np.cos(self.rot_z), np.sin(self.rot_z)

        rx = np.array([[1,0,0,0],[0,cx,-sx,0],[0,sx,cx,0],[0,0,0,1]], dtype=np.float32)
        ry = np.array([[cy,0,sy,0],[0,1,0,0],[-sy,0,cy,0],[0,0,0,1]], dtype=np.float32)
        rz = np.array([[cz,-sz,0,0],[sz,cz,0,0],[0,0,1,0],[0,0,0,1]], dtype=np.float32)

        sc = np.eye(4, dtype=np.float32)
        sc[0,0] = self.scale_x
        sc[1,1] = self.scale_y
        sc[2,2] = self.scale_z

        return trans @ ry @ rx @ rz @ sc

@dataclass
class MeshRenderer:
    mesh_type: str = "cube"
    color: Tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    wireframe: bool = False

@dataclass
class Camera3D:
    fov: float = 70.0
    near: float = 0.1
    far: float = 100.0
    speed: float = 5.0
    mouse_sensitivity: float = 0.1

@dataclass
class FlyController:
    speed: float = 8.0

@dataclass
class Rotator:
    speed_x: float = 0.0
    speed_y: float = 0.5
    speed_z: float = 0.0

@dataclass
class Light:
    color: Tuple[float, float, float] = (1.0, 1.0, 1.0)
    intensity: float = 1.0
    ambient: float = 0.2

@dataclass
class Oscillator:
    """Осциллятор (движение вверх-вниз)"""
    amplitude: float = 1.0
    speed: float = 1.0
    offset: float = 0.0
