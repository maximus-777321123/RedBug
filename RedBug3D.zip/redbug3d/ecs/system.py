from abc import ABC, abstractmethod

class System(ABC):
    def __init__(self):
        self.world = None

    @abstractmethod
    def update(self, delta_time: float):
        pass
