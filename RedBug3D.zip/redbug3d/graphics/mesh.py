import moderngl
import numpy as np
from typing import Dict

class Mesh:
    def __init__(self, ctx, vertices, indices):
        self.ctx = ctx
        self.vbo = ctx.buffer(vertices.tobytes())
        self.ibo = ctx.buffer(indices.tobytes())
        self.vertex_count = len(indices)

    def create_vao(self, program):
        return self.ctx.vertex_array(
            program,
            [(self.vbo, '3f 3f', 'in_pos', 'in_normal')],
            self.ibo
        )

class CubeMesh(Mesh):
    def __init__(self, ctx):
        v = np.array([
            # Front
            -0.5, -0.5,  0.5,  0.0,  0.0,  1.0,
             0.5, -0.5,  0.5,  0.0,  0.0,  1.0,
             0.5,  0.5,  0.5,  0.0,  0.0,  1.0,
            -0.5,  0.5,  0.5,  0.0,  0.0,  1.0,
            # Back
             0.5, -0.5, -0.5,  0.0,  0.0, -1.0,
            -0.5, -0.5, -0.5,  0.0,  0.0, -1.0,
            -0.5,  0.5, -0.5,  0.0,  0.0, -1.0,
             0.5,  0.5, -0.5,  0.0,  0.0, -1.0,
            # Right
             0.5, -0.5,  0.5,  1.0,  0.0,  0.0,
             0.5, -0.5, -0.5,  1.0,  0.0,  0.0,
             0.5,  0.5, -0.5,  1.0,  0.0,  0.0,
             0.5,  0.5,  0.5,  1.0,  0.0,  0.0,
            # Left
            -0.5, -0.5, -0.5, -1.0,  0.0,  0.0,
            -0.5, -0.5,  0.5, -1.0,  0.0,  0.0,
            -0.5,  0.5,  0.5, -1.0,  0.0,  0.0,
            -0.5,  0.5, -0.5, -1.0,  0.0,  0.0,
            # Top
            -0.5,  0.5,  0.5,  0.0,  1.0,  0.0,
             0.5,  0.5,  0.5,  0.0,  1.0,  0.0,
             0.5,  0.5, -0.5,  0.0,  1.0,  0.0,
            -0.5,  0.5, -0.5,  0.0,  1.0,  0.0,
            # Bottom
            -0.5, -0.5, -0.5,  0.0, -1.0,  0.0,
             0.5, -0.5, -0.5,  0.0, -1.0,  0.0,
             0.5, -0.5,  0.5,  0.0, -1.0,  0.0,
            -0.5, -0.5,  0.5,  0.0, -1.0,  0.0,
        ], dtype=np.float32)

        idx = np.array([
            0,1,2, 0,2,3,
            4,5,6, 4,6,7,
            8,9,10, 8,10,11,
            12,13,14, 12,14,15,
            16,17,18, 16,18,19,
            20,21,22, 20,22,23,
        ], dtype=np.uint32)
        super().__init__(ctx, v, idx)

class SphereMesh(Mesh):
    def __init__(self, ctx, radius=0.5, sectors=16, stacks=12):
        verts = []
        for i in range(stacks + 1):
            phi = np.pi * i / stacks
            for j in range(sectors + 1):
                theta = 2 * np.pi * j / sectors
                x = radius * np.sin(phi) * np.cos(theta)
                y = radius * np.cos(phi)
                z = radius * np.sin(phi) * np.sin(theta)
                nx, ny, nz = x / radius, y / radius, z / radius
                verts.extend([x, y, z, nx, ny, nz])

        inds = []
        for i in range(stacks):
            for j in range(sectors):
                a = i * (sectors + 1) + j
                b = a + sectors + 1
                inds.extend([a, b, a + 1, a + 1, b, b + 1])

        super().__init__(ctx, np.array(verts, dtype=np.float32), np.array(inds, dtype=np.uint32))

class PlaneMesh(Mesh):
    def __init__(self, ctx, size=1.0):
        s = size / 2
        v = np.array([
            -s, 0, -s,  0, 1, 0,
             s, 0, -s,  0, 1, 0,
             s, 0,  s,  0, 1, 0,
            -s, 0,  s,  0, 1, 0,
        ], dtype=np.float32)
        i = np.array([0, 1, 2, 0, 2, 3], dtype=np.uint32)
        super().__init__(ctx, v, i)

class PyramidMesh(Mesh):
    """Пирамида (4 грани + основание)"""
    def __init__(self, ctx):
        v = np.array([
            # Основание (bottom)
            -0.5, -0.5,  0.5,  0, -1, 0,
             0.5, -0.5,  0.5,  0, -1, 0,
             0.5, -0.5, -0.5,  0, -1, 0,
            -0.5, -0.5, -0.5,  0, -1, 0,
            # Вершина (4 раза для разных граней)
             0.0,  0.5,  0.0,  0, 0.894, 0.447,   # front
             0.0,  0.5,  0.0,  0.447, 0.894, 0,   # right
             0.0,  0.5,  0.0,  0, 0.894, -0.447,  # back
             0.0,  0.5,  0.0, -0.447, 0.894, 0,   # left
        ], dtype=np.float32)

        idx = np.array([
            # Основание
            0, 1, 2, 0, 2, 3,
            # Front face
            0, 1, 4,
            # Right face
            1, 2, 5,
            # Back face
            2, 3, 6,
            # Left face
            3, 0, 7,
        ], dtype=np.uint32)
        super().__init__(ctx, v, idx)

class CylinderMesh(Mesh):
    """Цилиндр"""
    def __init__(self, ctx, radius=0.5, height=1.0, sectors=16):
        verts = []
        h = height / 2
        
        # Боковая поверхность
        for i in range(sectors + 1):
            angle = 2 * np.pi * i / sectors
            x = radius * np.cos(angle)
            z = radius * np.sin(angle)
            nx, nz = np.cos(angle), np.sin(angle)
            
            # Нижняя точка
            verts.extend([x, -h, z, nx, 0, nz])
            # Верхняя точка
            verts.extend([x, h, z, nx, 0, nz])
        
        # Центры для крышек
        verts.extend([0, -h, 0, 0, -1, 0])  # bottom center
        verts.extend([0, h, 0, 0, 1, 0])    # top center
        
        # Крышки
        for i in range(sectors):
            angle = 2 * np.pi * i / sectors
            x = radius * np.cos(angle)
            z = radius * np.sin(angle)
            verts.extend([x, -h, z, 0, -1, 0])
            verts.extend([x, h, z, 0, 1, 0])
        
        inds = []
        # Боковые грани
        for i in range(sectors):
            a = i * 2
            b = a + 2
            c = a + 1
            d = a + 3
            inds.extend([a, b, c, c, b, d])
        
        # Крышки
        bottom_center = (sectors + 1) * 2
        top_center = bottom_center + 1
        for i in range(sectors):
            a = top_center + 1 + i
            b = top_center + 1 + ((i + 1) % sectors)
            inds.extend([bottom_center, bottom_center + 1 + sectors + i, bottom_center + 1 + sectors + ((i + 1) % sectors)])
            inds.extend([top_center, top_center + 1 + sectors + ((i + 1) % sectors), top_center + 1 + sectors + i])
        
        super().__init__(ctx, np.array(verts, dtype=np.float32), np.array(inds, dtype=np.uint32))

class MeshCache:
    def __init__(self, ctx):
        self.ctx = ctx
        self.meshes: Dict[str, Mesh] = {}
        self.vaos: Dict[str, moderngl.VertexArray] = {}
        self._program = None

    def set_program(self, program):
        self._program = program

    def get_mesh(self, name: str):
        if name not in self.meshes:
            if name == "cube":
                self.meshes[name] = CubeMesh(self.ctx)
            elif name == "sphere":
                self.meshes[name] = SphereMesh(self.ctx)
            elif name == "plane":
                self.meshes[name] = PlaneMesh(self.ctx)
            elif name == "pyramid":
                self.meshes[name] = PyramidMesh(self.ctx)
            elif name == "cylinder":
                self.meshes[name] = CylinderMesh(self.ctx)
            else:
                self.meshes[name] = CubeMesh(self.ctx)
        return self.meshes[name]

    def get_vao(self, name: str):
        if name not in self.vaos and self._program:
            mesh = self.get_mesh(name)
            self.vaos[name] = mesh.create_vao(self._program)
        return self.vaos.get(name)
