VERTEX_SHADER_3D = """#version 330 core
in vec3 in_pos;
in vec3 in_normal;

uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;

out vec3 v_pos;
out vec3 v_normal;

void main() {
    vec4 world_pos = uModel * vec4(in_pos, 1.0);
    gl_Position = uProjection * uView * world_pos;
    v_pos = world_pos.xyz;
    v_normal = mat3(transpose(inverse(uModel))) * in_normal;
}
"""

FRAGMENT_SHADER_3D = """#version 330 core
in vec3 v_pos;
in vec3 v_normal;

uniform vec4 uColor;
uniform vec3 uLightPos;
uniform vec3 uLightColor;
uniform float uLightIntensity;
uniform float uAmbient;
uniform vec3 uCameraPos;

out vec4 FragColor;

void main() {
    vec3 normal = normalize(v_normal);

    // Ambient
    vec3 ambient = uAmbient * uLightColor;

    // Diffuse
    vec3 light_dir = normalize(uLightPos - v_pos);
    float diff = max(dot(normal, light_dir), 0.0);
    vec3 diffuse = diff * uLightColor * uLightIntensity;

    // Specular (Blinn-Phong)
    vec3 view_dir = normalize(uCameraPos - v_pos);
    vec3 halfway = normalize(light_dir + view_dir);
    float spec = pow(max(dot(normal, halfway), 0.0), 64.0);
    vec3 specular = spec * uLightColor * uLightIntensity * 0.5;

    vec3 result = (ambient + diffuse + specular) * uColor.rgb;
    FragColor = vec4(result, uColor.a);
}
"""
