from typing import NewType

Entity = NewType('Entity', int)

class EntityManager:
    def __init__(self):
        self._next_id = 0
        self._free_ids = []

    def create(self):
        if self._free_ids:
            return Entity(self._free_ids.pop())
        entity = Entity(self._next_id)
        self._next_id += 1
        return entity

    def destroy(self, entity):
        self._free_ids.append(entity)

    def reset(self):
        self._next_id = 0
        self._free_ids.clear()
