# redbug3d/ecs/physics.py

from .component import Transform3D
from .system import System

# ============ КОМПОНЕНТЫ ============

class CollisionShape:
    def __init__(self, shape_type="box", size=None, offset=(0, 0, 0)):
        self.shape_type = shape_type
        self.size = size
        self.offset = offset
        self.enabled = True

class RigidBody:
    def __init__(self, mass=1.0, gravity_scale=1.0, is_kinematic=False):
        self.mass = mass
        self.gravity_scale = gravity_scale
        self.is_kinematic = is_kinematic
        self.velocity = [0.0, 0.0, 0.0]
        self.use_gravity = True
        self.is_grounded = False

# ============ СИСТЕМА ============

class PhysicsSystem(System):
    def __init__(self, gravity=-20.0, ground_y=0):
        super().__init__()
        self.gravity = gravity
        self.ground_y = ground_y
    
    def update(self, world, delta_time):
        for entity in world.get_entities_with(RigidBody, Transform3D):
            rb = world.get_component(entity, RigidBody)
            t = world.get_component(entity, Transform3D)
            
            if rb.use_gravity and not rb.is_grounded:
                rb.velocity[1] += self.gravity * delta_time * rb.gravity_scale
            
            t.x += rb.velocity[0] * delta_time
            t.y += rb.velocity[1] * delta_time
            t.z += rb.velocity[2] * delta_time
            
            collision = world.get_component(entity, CollisionShape)
            if collision:
                height = collision.size[1] / 2 if collision.size else 0.5
                if t.y - height <= self.ground_y:
                    t.y = self.ground_y + height
                    rb.velocity[1] = 0
                    rb.is_grounded = True
                else:
                    rb.is_grounded = False
            
            t.update_matrix()
