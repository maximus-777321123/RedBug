from abc import ABC, abstractmethod

class System(ABC):
    def __init__(self):
        self.world = None

    @abstractmethod
    def update(self, delta_time: float):
        pass


# redbug3d/ecs/system.py

class LookAtSystem(System):
    """Система - поворачивает объекты к цели"""
    
    def update(self, delta_time):  # ← Убрал world, он берется из системы
        # Получаем world из системы
        world = self.world
        
        for entity in world.get_entities_with(Transform3D, LookAt):
            t = world.get_component(entity, Transform3D)
            look = world.get_component(entity, LookAt)
            
            if not look.enabled:
                continue
            
            target_transform = world.get_component(look.target_entity, Transform3D)
            if not target_transform:
                continue
            
            dx = target_transform.x - t.x
            dy = target_transform.y - t.y
            dz = target_transform.z - t.z
            
            if look.look_axis == "y":
                target_angle = np.arctan2(dx, dz)
                angle_diff = target_angle - t.rot_y
                while angle_diff > np.pi:
                    angle_diff -= 2 * np.pi
                while angle_diff < -np.pi:
                    angle_diff += 2 * np.pi
                t.rot_y += angle_diff * min(1.0, look.smoothness * delta_time)
            
            elif look.look_axis == "xy":
                target_angle_y = np.arctan2(dx, dz)
                target_angle_x = -np.arctan2(dy, np.sqrt(dx*dx + dz*dz))
                
                angle_diff_y = target_angle_y - t.rot_y
                while angle_diff_y > np.pi:
                    angle_diff_y -= 2 * np.pi
                while angle_diff_y < -np.pi:
                    angle_diff_y += 2 * np.pi
                t.rot_y += angle_diff_y * min(1.0, look.smoothness * delta_time)
                
                angle_diff_x = target_angle_x - t.rot_x
                while angle_diff_x > np.pi:
                    angle_diff_x -= 2 * np.pi
                while angle_diff_x < -np.pi:
                    angle_diff_x += 2 * np.pi
                t.rot_x += angle_diff_x * min(1.0, look.smoothness * delta_time)
            
            t.update_matrix()
