from typing import Dict, List, Type, Any, Set
from .entity import Entity, EntityManager
from .system import System

class World:
    def __init__(self):
        self.entity_manager = EntityManager()
        self.entities: Set[Entity] = set()
        self.components: Dict[Type, Dict[Entity, Any]] = {}
        self.systems: List[System] = []

    def create_entity(self):
        entity = self.entity_manager.create()
        self.entities.add(entity)
        return entity

    def destroy_entity(self, entity):
        if entity in self.entities:
            self.entities.remove(entity)
            for ct in self.components:
                self.components[ct].pop(entity, None)
            self.entity_manager.destroy(entity)

    def add_component(self, entity, component):
        ct = type(component)
        if ct not in self.components:
            self.components[ct] = {}
        self.components[ct][entity] = component

    def get_component(self, entity, component_type):
        return self.components.get(component_type, {}).get(entity, None)

    def has_component(self, entity, component_type):
        return entity in self.components.get(component_type, {})

    def get_entities_with(self, *component_types):
        if not component_types:
            return self.entities.copy()
        result = set(self.components.get(component_types[0], {}).keys())
        for ct in component_types[1:]:
            result &= set(self.components.get(ct, {}).keys())
        return result

    def add_system(self, system):
        system.world = self
        self.systems.append(system)

    def update(self, delta_time):
        for system in self.systems:
            system.update(delta_time)

    def destroy(self):
        for system in self.systems:
            if hasattr(system, 'destroy'):
                system.destroy()
        self.systems.clear()
        self.entities.clear()
        self.components.clear()
        self.entity_manager.reset()
