import numpy as np

class PerspectiveCamera:
    def __init__(self, width=1280, height=720, fov=70.0, near=0.1, far=100.0):
        self.width = width
        self.height = height
        self.fov = fov
        self.near = near
        self.far = far
        self.position = np.array([0.0, 3.0, 10.0], dtype=np.float32)
        self.yaw = -90.0
        self.pitch = -15.0
        self._dirty = True
        self._update_matrices()

    def _update_matrices(self):
        aspect = self.width / self.height
        f = 1.0 / np.tan(np.radians(self.fov) / 2.0)
        self.proj_matrix = np.array([
            [f/aspect, 0, 0, 0],
            [0, f, 0, 0],
            [0, 0, (self.far+self.near)/(self.near-self.far), (2*self.far*self.near)/(self.near-self.far)],
            [0, 0, -1, 0]
        ], dtype=np.float32)

        self.front = np.array([
            np.cos(np.radians(self.yaw)) * np.cos(np.radians(self.pitch)),
            np.sin(np.radians(self.pitch)),
            np.sin(np.radians(self.yaw)) * np.cos(np.radians(self.pitch))
        ], dtype=np.float32)
        self.front /= np.linalg.norm(self.front)

        up = np.array([0.0, 1.0, 0.0], dtype=np.float32)
        self.right = np.cross(self.front, up)
        self.right /= np.linalg.norm(self.right)
        self.up = np.cross(self.right, self.front)

        self.view_matrix = np.array([
            [self.right[0], self.right[1], self.right[2], -np.dot(self.right, self.position)],
            [self.up[0], self.up[1], self.up[2], -np.dot(self.up, self.position)],
            [-self.front[0], -self.front[1], -self.front[2], np.dot(self.front, self.position)],
            [0, 0, 0, 1]
        ], dtype=np.float32)
        self._dirty = False

    def mark_dirty(self):
        self._dirty = True
