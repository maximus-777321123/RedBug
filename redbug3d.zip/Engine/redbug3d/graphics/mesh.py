import moderngl
import numpy as np
from typing import Dict, List
import os
from PIL import Image

class SubMesh:
    def __init__(self, ctx, vertices, indices, material_name, texture=None, color=None):
        self.ctx = ctx
        self.material_name = material_name
        self.texture = texture
        self.color = color
        self.vertex_count = len(indices)
        
        if len(vertices) > 0:
            self.vbo = ctx.buffer(np.array(vertices, dtype=np.float32).tobytes())
            self.ibo = ctx.buffer(np.array(indices, dtype=np.uint32).tobytes())
        else:
            self.vbo = None
            self.ibo = None

    def create_vao(self, program):
        if self.vbo is None or self.ibo is None:
            return None
        return self.ctx.vertex_array(
            program,
            [(self.vbo, '3f 3f 2f', 'in_pos', 'in_normal', 'in_uv')],
            self.ibo
        )

class Mesh:
    def __init__(self, ctx):
        self.ctx = ctx
        self.submeshes: List[SubMesh] = []

    def add_submesh(self, vertices, indices, material_name, texture=None, color=None):
        submesh = SubMesh(self.ctx, vertices, indices, material_name, texture, color)
        self.submeshes.append(submesh)
        return submesh

    def create_vao(self, program):
        if self.submeshes:
            return self.submeshes[0].create_vao(program)
        return None
    
    def get_all_vaos(self, program):
        vaos = []
        for submesh in self.submeshes:
            vao = submesh.create_vao(program)
            if vao:
                vaos.append((vao, submesh))
        return vaos

class OBJMesh(Mesh):
    def __init__(self, ctx, filepath):
        super().__init__(ctx)
        
        base_dir = os.path.dirname(filepath)
        
        # Загружаем MTL
        mtl_data = self._load_mtl(filepath, base_dir)
        
        # Загружаем OBJ
        positions = []
        normals = []
        uvs = []
        current_material = None
        material_faces = {}
        
        with open(filepath, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                    
                if line.startswith('v '):
                    parts = line.split()
                    positions.append([float(parts[1]), float(parts[2]), float(parts[3])])
                elif line.startswith('vn '):
                    parts = line.split()
                    normals.append([float(parts[1]), float(parts[2]), float(parts[3])])
                elif line.startswith('vt '):
                    parts = line.split()
                    uvs.append([float(parts[1]), float(parts[2])])
                elif line.startswith('usemtl '):
                    current_material = line.split()[1]
                    if current_material not in material_faces:
                        material_faces[current_material] = []
                elif line.startswith('f '):
                    parts = line.split()
                    face = []
                    for part in parts[1:]:
                        indices = part.split('/')
                        v_idx = int(indices[0]) - 1
                        vt_idx = int(indices[1]) - 1 if len(indices) > 1 and indices[1] else -1
                        vn_idx = int(indices[2]) - 1 if len(indices) > 2 else 0
                        face.append((v_idx, vt_idx, vn_idx))
                    
                    if current_material and current_material in material_faces:
                        material_faces[current_material].append(face)
                    else:
                        if 'default' not in material_faces:
                            material_faces['default'] = []
                        material_faces['default'].append(face)
        
        has_normals = len(normals) > 0
        has_uvs = len(uvs) > 0
        
        for mat_name, mat_faces in material_faces.items():
            if not mat_faces:
                continue
                
            vertices = []
            indices = []
            index_map = {}
            current_index = 0
            
            for face in mat_faces:
                for i in range(1, len(face) - 1):
                    tri = [face[0], face[i], face[i + 1]]
                    for v_idx, vt_idx, vn_idx in tri:
                        key = (v_idx, vn_idx, vt_idx)
                        if key not in index_map:
                            pos = positions[v_idx] if v_idx < len(positions) else [0, 0, 0]
                            
                            if has_normals and vn_idx >= 0 and vn_idx < len(normals):
                                norm = normals[vn_idx]
                            else:
                                norm = [0, 0, 0]
                            
                            if has_uvs and vt_idx >= 0 and vt_idx < len(uvs):
                                uv = uvs[vt_idx]
                            else:
                                uv = [0, 0]
                            
                            vertices.extend([pos[0], pos[1], pos[2], norm[0], norm[1], norm[2], uv[0], uv[1]])
                            index_map[key] = current_index
                            current_index += 1
                        indices.append(index_map[key])
            
            texture = None
            color = None
            
            if mat_name in mtl_data:
                if 'texture_path' in mtl_data[mat_name]:
                    texture = self._load_texture(mtl_data[mat_name]['texture_path'])
                if 'color' in mtl_data[mat_name]:
                    color = mtl_data[mat_name]['color']
            
            if vertices and indices:
                self.add_submesh(vertices, indices, mat_name, texture, color)
    
    def _load_texture(self, path):
        try:
            img = Image.open(path).convert('RGBA')
            img = img.transpose(Image.FLIP_TOP_BOTTOM)
            texture = self.ctx.texture(img.size, 4, img.tobytes())
            texture.use()
            texture.build_mipmaps()
            return texture
        except Exception as e:
            print(f"Error loading texture {path}: {e}")
            return None
    
    def _load_mtl(self, obj_path, base_dir):
        mtl_data = {}
        mtl_path = None
        
        try:
            with open(obj_path, 'r') as f:
                for line in f:
                    if line.startswith('mtllib '):
                        mtl_name = line.strip().split()[1]
                        mtl_path = os.path.join(base_dir, mtl_name)
                        break
        except:
            pass
        
        if not mtl_path or not os.path.exists(mtl_path):
            return mtl_data
        
        try:
            with open(mtl_path, 'r') as f:
                current_mat = None
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    if line.startswith('newmtl '):
                        current_mat = line.split()[1]
                        mtl_data[current_mat] = {}
                    
                    elif line.startswith('Kd ') and current_mat:
                        parts = line.split()
                        if len(parts) >= 4:
                            r = float(parts[1])
                            g = float(parts[2])
                            b = float(parts[3])
                            mtl_data[current_mat]['color'] = (r, g, b, 1.0)
                    
                    elif line.startswith('map_Kd ') and current_mat:
                        tex_name = line.split()[1]
                        tex_path = os.path.join(base_dir, tex_name)
                        if os.path.exists(tex_path):
                            mtl_data[current_mat]['texture_path'] = tex_path
        except Exception as e:
            print(f"Error loading MTL: {e}")
        
        return mtl_data
    
    def get_bounds(self):
        """Возвращает bounding box модели (min, max)"""
        if not hasattr(self, '_bounds'):
            all_vertices = []
            for submesh in self.submeshes:
                if submesh.vbo:
                    data = submesh.vbo.read()
                    verts = np.frombuffer(data, dtype=np.float32).reshape(-1, 8)
                    all_vertices.append(verts[:, :3])
            
            if all_vertices:
                all_verts = np.vstack(all_vertices)
                self._bounds = (all_verts.min(axis=0), all_verts.max(axis=0))
            else:
                self._bounds = (np.array([-0.5, -0.5, -0.5]), np.array([0.5, 0.5, 0.5]))
        
        return self._bounds

    def get_size(self):
        """Возвращает размер модели (width, height, depth)"""
        min_bound, max_bound = self.get_bounds()
        size = max_bound - min_bound
        return (float(size[0]), float(size[1]), float(size[2]))

class MeshCache:
    def __init__(self, ctx, models_dir="redbug3d/models"):
        self.ctx = ctx
        self.models_dir = models_dir
        self.meshes: Dict[str, Mesh] = {}
        self._program = None

    def set_program(self, program):
        self._program = program

    def get_mesh(self, name: str):
        if name not in self.meshes:
            obj_path = os.path.join(self.models_dir, f"{name}.obj")
            if os.path.exists(obj_path):
                self.meshes[name] = OBJMesh(self.ctx, obj_path)
            else:
                self.meshes[name] = Mesh(self.ctx)
        return self.meshes[name]

    def get_vao(self, name: str):
        mesh = self.get_mesh(name)
        return mesh.create_vao(self._program)
    
    def get_all_vaos(self, name: str):
        mesh = self.get_mesh(name)
        return mesh.get_all_vaos(self._program)
