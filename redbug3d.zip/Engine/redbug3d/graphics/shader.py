# redbug3d/graphics/shader.py

VERTEX_SHADER_3D = """#version 330 core
in vec3 in_pos;
in vec3 in_normal;
in vec2 in_uv;

uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;

out vec3 v_pos;
out vec3 v_normal;
out vec2 v_uv;

void main() {
    vec4 world_pos = uModel * vec4(in_pos, 1.0);
    gl_Position = uProjection * uView * world_pos;
    v_pos = world_pos.xyz;
    v_normal = mat3(transpose(inverse(uModel))) * in_normal;
    v_uv = in_uv;
}
"""


FRAGMENT_SHADER_3D = """#version 330 core
in vec3 v_pos;
in vec3 v_normal;
in vec2 v_uv;

uniform vec4 uColor;
uniform vec3 uLightPos;
uniform vec3 uLightColor;
uniform float uLightIntensity;
uniform float uAmbient;
uniform float uDiffuse;
uniform float uSpecular;
uniform vec3 uCameraPos;
uniform sampler2D uTexture;
uniform int uUseTexture;

out vec4 FragColor;

void main() {
    vec3 normal = normalize(v_normal);

    // Ambient
    vec3 ambient = uAmbient * uLightColor;

    // Diffuse
    vec3 light_dir = normalize(uLightPos - v_pos);
    float diff = max(dot(normal, light_dir), 0.0);
    vec3 diffuse = diff * uLightColor * uLightIntensity * uDiffuse;

    // Specular
    vec3 view_dir = normalize(uCameraPos - v_pos);
    vec3 halfway = normalize(light_dir + view_dir);
    float spec = pow(max(dot(normal, halfway), 0.0), 64.0);
    vec3 specular = spec * uLightColor * uLightIntensity * uSpecular;

    vec3 base_color;
    if (uUseTexture == 1) {
        base_color = texture(uTexture, v_uv).rgb;
    } else {
        base_color = uColor.rgb;
    }

    vec3 result = (ambient + diffuse + specular) * base_color;
    FragColor = vec4(result, uColor.a);
}
"""
