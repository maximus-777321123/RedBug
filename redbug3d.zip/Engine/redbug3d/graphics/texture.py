import moderngl
import numpy as np
from typing import Dict

class TextureManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def initialize(self, ctx):
        if not self._initialized:
            self.ctx = ctx
            self.textures: Dict[int, moderngl.Texture] = {}
            self._next_id = 1
            self._default_texture = None
            self._initialized = True
            self._create_default_texture()

    def _create_default_texture(self):
        size = 64
        data = np.zeros((size, size, 4), dtype=np.uint8)
        for y in range(size):
            for x in range(size):
                c = 255 if ((x//8)+(y//8))%2==0 else 128
                data[y,x] = [c,c,c,255]
        tex = self.ctx.texture((size,size), 4, data.tobytes())
        tex.build_mipmaps()
        self._default_texture = tex

    def get_texture(self, tid):
        return self.textures.get(tid, self._default_texture)

    def create_color(self, color=(255,0,0,255), size=4):
        data = np.zeros((size,size,4), dtype=np.uint8)
        data[:,:] = color
        tex = self.ctx.texture((size,size), 4, data.tobytes())
        tex.build_mipmaps()
        tid = self._next_id
        self._next_id += 1
        self.textures[tid] = tex
        return tid

    def destroy(self):
        for tex in self.textures.values():
            tex.release()
        if self._default_texture:
            self._default_texture.release()
        self.textures.clear()

texture_manager = TextureManager()
