import glfw

class Input3D:
    _window = None
    _keys = {}
    _mouse_x = 0.0
    _mouse_y = 0.0
    _prev_x = 0.0
    _prev_y = 0.0
    _dx = 0.0
    _dy = 0.0
    _first = True

    @classmethod
    def initialize(cls, window):
        cls._window = window

    @classmethod
    def _on_key(cls, key, action):
        cls._keys[key] = (action in (glfw.PRESS, glfw.REPEAT))

    @classmethod
    def _on_mouse_move(cls, x, y):
        cls._mouse_x = x
        cls._mouse_y = y

    @classmethod
    def _update(cls):
        if cls._first:
            cls._prev_x = cls._mouse_x
            cls._prev_y = cls._mouse_y
            cls._first = False
        cls._dx = cls._mouse_x - cls._prev_x
        cls._dy = cls._mouse_y - cls._prev_y
        cls._prev_x = cls._mouse_x
        cls._prev_y = cls._mouse_y

    @staticmethod
    def get_key(key):
        return Input3D._keys.get(key, False)

    @staticmethod
    def get_mouse_delta():
        return Input3D._dx, Input3D._dy
