# redbug3d/utils/pcs.py
import glfw
import numpy as np
from redbug3d.ecs.system import System
from redbug3d.ecs.component import Transform3D, MeshRenderer
from redbug3d.io.input_manager import Input3D

class PlayerPhysics:
    def __init__(self, speed=5.0, height=1.8, gravity=-15.0, jump_speed=6.0, radius=0.3):
        self.speed = speed
        self.height = height
        self.gravity = gravity
        self.jump_speed = jump_speed
        self.velocity_y = 0.0
        self.is_grounded = False
        self.mouse_sensitivity = 0.1
        self.radius = radius

class PlayerPhysicsSystem(System):
    def __init__(self, camera):
        super().__init__()
        self.camera = camera
        
    def _get_collision_entities(self, world):
        """Получает объекты с коллизией"""
        entities = []
        for entity in world.get_entities_with(Transform3D, MeshRenderer):
            no_collision = False
            try:
                if entity in world._components:
                    for comp in world._components[entity]:
                        if hasattr(comp, 'no_collision') and comp.no_collision:
                            no_collision = True
                            break
            except:
                pass
            
            if not no_collision:
                entities.append(entity)
        return entities
    
    def _resolve_collision(self, pos, world, controller):
        """Только горизонтальная коллизия - не дает пройти сквозь стены"""
        radius = controller.radius
        
        for entity in self._get_collision_entities(world):
            t = world.get_component(entity, Transform3D)
            if t is None:
                continue
            
            obj_pos = np.array([t.x, t.y, t.z], dtype=np.float32)
            
            # Размер объекта
            scale_x = t.scale_x if hasattr(t, 'scale_x') else 1.0
            scale_z = t.scale_z if hasattr(t, 'scale_z') else 1.0
            scale_y = t.scale_y if hasattr(t, 'scale_y') else 1.0
            
            obj_radius = max(scale_x, scale_z) * 0.5
            obj_height = scale_y * 0.5
            
            # ВЕРТИКАЛЬНАЯ ПРОВЕРКА: если игрок слишком высоко или низко - пропускаем
            player_bottom = pos[1] - controller.height
            player_top = pos[1]
            obj_bottom = obj_pos[1] - obj_height
            obj_top = obj_pos[1] + obj_height
            
            # Если игрок не пересекается по Y с объектом - пропускаем
            if player_top < obj_bottom or player_bottom > obj_top:
                continue
            
            # ГОРИЗОНТАЛЬНАЯ ПРОВЕРКА
            dx = pos[0] - obj_pos[0]
            dz = pos[2] - obj_pos[2]
            dist = np.sqrt(dx*dx + dz*dz)
            
            if dist < radius + obj_radius and dist > 0.001:
                # Отталкиваем
                overlap = (radius + obj_radius - dist) / dist
                pos[0] += dx * overlap * 0.5
                pos[2] += dz * overlap * 0.5

    def update(self, dt):
        world = self.world
        if world is None:
            return
            
        for entity in world.get_entities_with(PlayerPhysics):
            controller = world.get_component(entity, PlayerPhysics)
            pos = self.camera.position
            
            # --- МЫШЬ ---
            dx, dy = Input3D.get_mouse_delta()
            self.camera.yaw += dx * controller.mouse_sensitivity
            self.camera.pitch -= dy * controller.mouse_sensitivity
            self.camera.pitch = max(-89.0, min(89.0, self.camera.pitch))
            self.camera._dirty = True
            
            # --- ВЕКТОРЫ ---
            front = self.camera.front
            right = self.camera.right
            
            front_h = np.array([front[0], 0, front[2]], dtype=np.float32)
            if np.linalg.norm(front_h) > 0:
                front_h = front_h / np.linalg.norm(front_h)
            
            right_h = np.array([right[0], 0, right[2]], dtype=np.float32)
            if np.linalg.norm(right_h) > 0:
                right_h = right_h / np.linalg.norm(right_h)
            
            # --- ДВИЖЕНИЕ (ТОЛЬКО ГОРИЗОНТАЛЬ) ---
            speed = controller.speed * dt
            if Input3D.get_key(glfw.KEY_LEFT_SHIFT) or Input3D.get_key(glfw.KEY_RIGHT_SHIFT):
                speed *= 1.5
            
            new_pos = pos.copy()
            
            if Input3D.get_key(glfw.KEY_W):
                new_pos[0] += front_h[0] * speed
                new_pos[2] += front_h[2] * speed
            if Input3D.get_key(glfw.KEY_S):
                new_pos[0] -= front_h[0] * speed
                new_pos[2] -= front_h[2] * speed
            if Input3D.get_key(glfw.KEY_A):
                new_pos[0] -= right_h[0] * speed
                new_pos[2] -= right_h[2] * speed
            if Input3D.get_key(glfw.KEY_D):
                new_pos[0] += right_h[0] * speed
                new_pos[2] += right_h[2] * speed
            
            # --- ПРИМЕНЯЕМ КОЛЛИЗИЮ ---
            self._resolve_collision(new_pos, world, controller)
            
            # --- ПРИМЕНЯЕМ ДВИЖЕНИЕ (ТОЛЬКО X и Z) ---
            pos[0] = new_pos[0]
            pos[2] = new_pos[2]
            
            # --- ГРАВИТАЦИЯ И ПРЫЖОК ---
            if Input3D.get_key(glfw.KEY_SPACE) and controller.is_grounded:
                controller.velocity_y = controller.jump_speed
                controller.is_grounded = False
            
            controller.velocity_y += controller.gravity * dt
            pos[1] += controller.velocity_y * dt
            
            # --- ЗЕМЛЯ ---
            if pos[1] <= controller.height:
                pos[1] = controller.height
                controller.velocity_y = 0.0
                controller.is_grounded = True
            
            self.camera.position = pos
            break
