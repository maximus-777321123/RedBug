from redbug3d import Engine3D, World
from redbug3d.ecs.component import Transform3D, MeshRenderer, Camera3D, FlyController, Rotator, Light
from redbug3d.ecs.system import System
from redbug3d.graphics.texture import texture_manager
from redbug3d.graphics.mesh import MeshCache
from redbug3d.graphics.camera import PerspectiveCamera
from redbug3d.graphics.shader import VERTEX_SHADER_3D, FRAGMENT_SHADER_3D
from redbug3d.io.input_manager import Input3D

class RotatorSystem(System):
    def update(self, dt):
        for entity in self.world.get_entities_with(Transform3D, Rotator):
            t = self.world.get_component(entity, Transform3D)
            r = self.world.get_component(entity, Rotator)
            t.rot_y += r.speed_y * dt
            t.rot_x += r.speed_x * dt
            t.rot_z += r.speed_z * dt
